#ifndef CURVEMODEL_H
#define CURVEMODEL_H

#include <QList>
#include <QPoint>
#include <QObject>
#include <QPointF>
#include <QAbstractTableModel>

#define PROPERTY_GET_SET(type,member,fcn) \
    type get##fcn() const { return member;} \
    void set##fcn(type const & other)  {  \
            if(member == other) return; \
            member =  other; \
            emit sig##fcn##Changed();\
    } \
    // 

enum POINT_TYPE_E{
    POINT_NORM,     // 普通点
    POINT_END       // 端点
};

struct ITEM_POINT_S{
    QPoint pos;        // 数据点
    QPointF handleL;    // 左控制点
    QPointF handleR;    // 右控制点
    bool bMove = false; // 是否为控制点
    POINT_TYPE_E enType;
};

struct RANGE_POINT_S
{
    QPointF posL;
    QPointF posR;
};


using PointsPtr = std::shared_ptr<QList<ITEM_POINT_S>>;
using ControlsPtr = std::shared_ptr<QList<int>>;


/**
 * @brief 数据点 model 用于 qml 交互，界面展示与操作数据
 *    x,y
 *    1: 1,2
 *    2: 3,4
 *    3: ...
 */
class CurvePointsModel : public QAbstractTableModel{
    Q_OBJECT
public:
    CurvePointsModel(const PointsPtr & points, QObject * parent = nullptr); 

    Q_INVOKABLE virtual int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    Q_INVOKABLE virtual int columnCount(const QModelIndex &parent = QModelIndex()) const override;
    Q_INVOKABLE virtual QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    Q_INVOKABLE virtual bool setData(const QModelIndex &index, const QVariant &value, int role = Qt::EditRole) override;

    void setCurveData(const QList<int> & lstData);
    
private:
    PointsPtr m_pPoints;  // 数据点
};

/**
 * @brief 控制点 model 用于 qml 交互，界面展示与操作数据
 */
class CurveControlsModel : public QAbstractTableModel{
    Q_OBJECT
public:
    CurveControlsModel(const ControlsPtr & controls, const PointsPtr & points,QObject * parent = nullptr); 

    Q_INVOKABLE virtual int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    Q_INVOKABLE virtual int columnCount(const QModelIndex &parent = QModelIndex()) const override;
    Q_INVOKABLE virtual QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    Q_INVOKABLE virtual bool setData(const QModelIndex &index, const QVariant &value, int role = Qt::EditRole) override;

    void setControl(const QList<int> & lstIndex);

private:
    ITEM_POINT_S & controlMapPoint(int nIndex) const;
private:
    ControlsPtr m_pControls;  // 控制点
    PointsPtr m_pPoints;  // 控制点
};


class CurveModel : public QObject{
    Q_OBJECT
public:
    CurveModel(QObject * parent = nullptr);

    /**
     * @brief 设置曲线数据
     * @param lstData 索引为 x 轴；值为 y 轴
     */
    void setCurveData(const QList<int> & lstData);

    /**
     * @brief 设置控制点索引
     * @param lstIndex m_pPoints 的索引
     */
    void setControl(const QList<int> & lstIndex);

    /**
     * @brief nIndex 对应的控制点改变，根据三阶贝塞尔，更新曲线
     * @param nIndex m_pControls 的索引
     */
    void modifyCurve(int nIndex);

    /**
     * @brief nIndex 对应的控制点改变，修改临近点的 handle
     * @param nIndex m_pControls 的索引 
     */
    void modifyHandle(int nIndex);

private:
    /* m_pControls 前后索引查找 */
    int frontControltIndex(int nIndex);
    int nextControlIndex(int nIndex);


    /* 三阶贝塞尔曲线 */
    QPointF beizerOrder3(const ITEM_POINT_S & start, const ITEM_POINT_S & end, float t);
    double x2tBeizerCubic(const ITEM_POINT_S & start, const ITEM_POINT_S & end, double x);
    double t2yBeizerCubic(const ITEM_POINT_S & start, const ITEM_POINT_S & end, double x);

    /**
     * @brief 更新 [nStart, nEnd] 之间的曲线数据
     * @param nStart m_pControls 的索引 
     * @param nEnd m_pControls 的索引 
     */
    void updateCurve(int nStart , int nEnd);

    /**
     * @brief 更新控制点
     * @param nIndex m_pControls 的索引
     */
    void updateHandle(int nIndex);
    void updateHandleEnd(int nIndex);
    void updateHandleMiddle(int nIndex);
    void updateHandle(const QList<int> & lstIndex);

    /**
     * @brief m_pControls 映射到 m_pPoints 中的点
     * @param nIndex m_pControls 的索引
     * @return m_pPoints 中的点
     */
    ITEM_POINT_S & controlMapPoint(int nIndex);

signals:
    void sigPointsModleChanged();
    void sigControlsModelChanged();

private:
    PointsPtr m_pPoints; // 数据点
    ControlsPtr m_pControls; // 控制点在数据点容器的索引，值升序且唯一

    CurvePointsModel* m_pointsModle;
    Q_PROPERTY(CurvePointsModel* pointsModle MEMBER  m_pointsModle NOTIFY sigPointsModleChanged)

    CurveControlsModel* m_controlsModle;
    Q_PROPERTY(CurveControlsModel* controlsModle MEMBER  m_controlsModle NOTIFY sigControlsModelChanged)
};



#endif /* CURVEMODEL_H */

