#ifndef EQUATIONSOLVER_H
#define EQUATIONSOLVER_H

#include <vector>

class EquationSolver{

public:

    /**
     * @brief 求解器 0 = a * x^3 + b * x^2 + c * x + d
     * @param a 
     * @param b 
     * @param c 
     * @param d 
     * @return 所有实根
     */
    static std::vector<double> solver(double a,double b,double c,double d);

private:
    /**
     * @brief 盛金公式 0 = a * x^3 + b * x^2 + c * x + d
     * @param a  不为 0
     * @param b 
     * @param c 
     * @param d 
     * @return 所有实根
     */
    std::vector<double> shenjinCubic(double a,double b,double c,double d);
    
    /**
     * @brief 公式法 0 = a * x^2 + b * x + c
     * @param a 不为 0
     * @param b 
     * @param c 
     * @return 所有实根
     */
    std::vector<double> formulasQuadratic(double a,double b,double c);

    /**
     * @brief 线性方程 0 = a * x + b
     * @param a 不为 0
     * @param b 
     * @return 实根
     */
    std::vector<double> formulasLinear(double a, double b);
};


#endif // EQUATIONSOLVER_H
