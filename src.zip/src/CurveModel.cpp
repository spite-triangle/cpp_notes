#include "CurveModel.h"

#include <QSet>

#include <math.h>
#include <stdexcept>

#include "EquationSolver.h"

#define QT_FORCE_ASSERTS

namespace Internal
{

qreal distance2(const QPointF& pt1, const QPointF& pt2){
    QPointF pt = pt1 - pt2;
    return pt.x() * pt.x() + pt.y() * pt.y();
}

qreal distance(const QPointF& pt1, const QPointF& pt2){
    return sqrt(distance2(pt1, pt2));
}

/**
 * @brief projection a点到直线bc上的投影
 * @param a
 * @param b
 * @param c
 * @return
 */
QPointF projection(const QPointF& a, const QPointF& b, const QPointF& c){
    QPointF bc = c - b;
    QPointF ba = a - b;

    qreal d = (bc.x() * ba.x() + bc.y() * ba.y()) / distance2(b, c);
    return d * bc + b;
}

} // namespace Internal


/**
 * MARK: 曲线数据点
 */

CurvePointsModel::CurvePointsModel(const PointsPtr &points, QObject *parent)
    : QAbstractTableModel(parent), m_pPoints(points)
{
}

int CurvePointsModel::rowCount(const QModelIndex &parent) const
{
    if(m_pPoints == nullptr ) return 0;
    return m_pPoints->size();
}

int CurvePointsModel::columnCount(const QModelIndex &parent) const
{
    // x,y
    return  2;
}

QVariant CurvePointsModel::data(const QModelIndex &index, int role) const
{
    if(m_pPoints == nullptr || index.isValid() == false) return  QVariant();

    int nRow = index.row();
    int nCol = index.column();

    if(role == Qt::DisplayRole || role == Qt::EditRole){
        auto & item = m_pPoints->at(nRow).pos;
        switch (nCol)
        {
            case 0: return item.x(); 
            case 1: return item.y(); 
        }
    }
    return  QVariant();
}

bool CurvePointsModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    if(m_pPoints == nullptr || index.isValid() == false || role != Qt::EditRole) return false;

    auto & item = (*m_pPoints)[index.row()].pos;
    int val = value.toInt();
    switch (index.column())
    {
    case 0:
        if(item.x() == val) return false;
        item.setX(val);    
        break;
    case 1:
        if(item.y() == val) return false;
        item.setY(val);    
        break;
    default:
        break;
    }

    return true;
}

void CurvePointsModel::setCurveData(const QList<int> &lstData)
{
    if(lstData.size() <= 0) return;

    beginResetModel();
    m_pPoints->clear();

    for (size_t index = 0; index < lstData.size(); index++)
    {
        ITEM_POINT_S item;
        item.pos.setX(index);
        item.pos.setY(lstData[index]);
        m_pPoints->append(item);
    }
    endResetModel();
}



/**
 * MARK: 控制点
 */

CurveControlsModel::CurveControlsModel(const ControlsPtr &controls, const PointsPtr &points, QObject *parent)
    : QAbstractTableModel(parent), m_pPoints(points), m_pControls(controls)
{
}

int CurveControlsModel::rowCount(const QModelIndex &parent) const
{
    return m_pControls->size();
}

int CurveControlsModel::columnCount(const QModelIndex &parent) const
{
    return 2;
}

QVariant CurveControlsModel::data(const QModelIndex &index, int role) const
{
    if(m_pPoints == nullptr || m_pControls == nullptr || index.isValid() == false) return  QVariant();

    int nRow = index.row();
    int nCol = index.column();

    if(role == Qt::DisplayRole || role == Qt::EditRole){
        auto & item = controlMapPoint(nRow).pos;

        switch (nCol)
        {
            case 0: return item.x(); 
            case 1: return item.y(); 
        }
    }
    return  QVariant();
}

Q_INVOKABLE bool CurveControlsModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    if( m_pControls == nullptr || m_pPoints == nullptr || index.isValid() == false || role != Qt::EditRole) return false;

    auto & item = controlMapPoint(index.row()).pos;
    int val = value.toInt();
    switch (index.column())
    {
    case 0:
        if(item.x() == val) return false;
        item.setX(val);    
        break;
    case 1:
        if(item.y() == val) return false;
        item.setY(val);    
        break;
    default:
        break;
    }

    return true;
}

void CurveControlsModel::setControl(const QList<int> &lstIndex)
{
    if(lstIndex.size() <= 0) return;

    beginResetModel();
    m_pControls->clear();
    m_pControls->append(lstIndex);
    endResetModel();
}

ITEM_POINT_S & CurveControlsModel::controlMapPoint(int nIndex) const
{
    auto & controls = *m_pControls;
    auto & points = *m_pPoints;
    return points[controls[nIndex]];
}

/**
 * MARK: 曲线
 */

CurveModel::CurveModel(QObject *parent)
    : QObject(parent)
{
    m_pPoints = std::make_shared<QList<ITEM_POINT_S>>();
    m_pControls = std::make_shared<QList<int>>();

    m_pointsModle = new CurvePointsModel(m_pPoints,this);
    m_controlsModle = new CurveControlsModel(m_pControls, m_pPoints, this);
}

void CurveModel::setCurveData(const QList<int> &lstData)
{
    m_pointsModle->setCurveData(lstData);
}

void CurveModel::setControl(const QList<int> &lstIndex)
{
    if(lstIndex.size() <= 0) return;

    // 必须先调用 setCurveData
    Q_ASSERT(m_pPoints->size() > 0);

    // 清除标志
    for(auto & item : *m_pPoints){
        item.bMove = false;
    }

    // 去重并设置标记
    QSet<int> set;
    for (auto & index : lstIndex)
    {
        Q_ASSERT(index >= 0 && index < m_pPoints->size());

        set.insert(index);
        (*m_pPoints)[index].bMove = true;
    }
    auto indexes = set.toList();
    qSort(indexes);

    // 设置控制点
    m_controlsModle->setControl(indexes);

    // 更新控制点
    updateHandle(indexes);
}

void CurveModel::modifyCurve(int nIndex)
{
    if(m_pControls == nullptr || nIndex < 0 || nIndex >= m_pControls->size()) return;

    // 根据 nIndex 查找需要修改的控制点, 并更新控制点
    modifyHandle(nIndex);

    int nStart = frontControltIndex(frontControltIndex(nIndex));
    int nEnd = nextControlIndex(nextControlIndex(nIndex));

    // 在该区间控制点范围内，曲线数据需要被修改
    updateCurve(nStart, nEnd);
}

void CurveModel::modifyHandle(int nIndex)
{
    int nFront = frontControltIndex(nIndex);
    int nNext = nextControlIndex(nIndex);

    // QList<int> lst;
    // if(nFront != nIndex){
    //     lst.push_back(nFront);
    // }
    // if(nNext != nIndex){
    //     lst.push_back(nNext);
    // }
    updateHandle({nFront, nNext});
}

int CurveModel::frontControltIndex(int nIndex)
{
    if(nIndex <= 0) return 0;
    return nIndex - 1;
}

int CurveModel::nextControlIndex(int nIndex)
{
    if(nIndex >= m_pControls->size() - 1) return m_pControls->size() - 1; 
    return nIndex + 1;
}


QPointF CurveModel::beizerOrder3(const ITEM_POINT_S &start, const ITEM_POINT_S &end, float t)
{
    if(t <= 0) return start.pos;
    if(t >= 1) return end.pos;
    return start.pos * pow(1-t, 3) + 3 * start.handleR * pow(1-t, 2) * t + 3 * end.handleL * (1 - t) * pow(t, 2) + end.pos * pow(t,3);
}

double CurveModel::x2tBeizerCubic(const ITEM_POINT_S &start, const ITEM_POINT_S &end, double x)
{
    const auto & p0 = start.pos;
    const auto & p1 = start.handleR;
    const auto & p2 = end.handleL;
    const auto & p3 = end.pos;

    double a = p3.x() - 3 * p2.x() + 3 * p1.x() - p0.x();
    double b = 3 * (p2.x() - 2 * p1.x() + p0.x());
    double c = 3 * (p1.x() - p0.x());
    double d = p0.x() - x;
    auto res = EquationSolver::solver(a,b,c,d);

    for (auto & item : res)
    {
        if(item < 0) continue;
        if(item > 1) continue;

        return item;
    }

    // 无解
    return -1.;
}

double CurveModel::t2yBeizerCubic(const ITEM_POINT_S &start, const ITEM_POINT_S &end, double t)
{
    const auto & p0 = start.pos.y();
    const auto & p1 = start.handleR.y();
    const auto & p2 = end.handleL.y();
    const auto & p3 = end.pos.y();

    return p0 * pow(1-t, 3) + 3 * p1 * pow(1-t, 2) * t + 3 * p2 * (1 - t) * pow(t, 2) + p3 * pow(t,3);
}

void CurveModel::updateHandle(const QList<int> &lstIndex)
{
    for (auto & index : lstIndex)
    {
        updateHandle(index);
    } 
}

void CurveModel::updateCurve(int nStartIndex, int nEndIndex)
{

    auto & controls = *m_pControls;
    auto & points = *m_pPoints;

    // [nStartIndex, nEndIndex] 控制点区间，两个控制点之间为一段贝塞尔曲线
    for (size_t index = nStartIndex; index < nEndIndex; ++index)
    {
        // [nBegain, nEnd] 数据点区间 
        int nBegain = controls[index];
        int nEnd = controls[index + 1];

        // [nBegin, nEnd] 曲线的端点
        auto & beginPoint = points[nBegain];
        auto & endPoint = points[nEnd];

        // 插值计算 [nBegin，nEnd] 之间的数据点
        for (size_t curr = nBegain; curr <= nEnd; ++curr)
        {
            auto & currPoint = points[curr];

            auto t = x2tBeizerCubic(beginPoint, endPoint, currPoint.pos.x());
            if(t < 0){
                throw std::runtime_error("no solver");
            }

            auto y = t2yBeizerCubic(beginPoint, endPoint, t);

            currPoint.pos.setY(roundl(y));
        }
    }
}

void CurveModel::updateHandle(int nIndex)
{
    if(nIndex == 0 || nIndex == m_pControls->size() - 1){
        // 端点
        updateHandleEnd(nIndex);
    }else if(nIndex > 0 && nIndex < m_pControls->size()){
        // 中间点
        updateHandleMiddle(nIndex);
    }
}

void CurveModel::updateHandleEnd(int nIndex)
{
    auto & curr = controlMapPoint(nIndex);

    if(nIndex == 0){
        const auto & nextPos = controlMapPoint(nIndex + 1).pos;
        curr.handleR = QPointF(curr.pos.x() + (nextPos.x() - curr.pos.x()) * 0.25, 0);
    }else if(nIndex == m_pControls->size() - 1)
    {
        const auto & prePos = controlMapPoint(nIndex -1).pos;
        curr.handleL = QPointF(curr.pos.x() + (prePos.x() - curr.pos.x()) * 0.25, 0);
    }
}

void CurveModel::updateHandleMiddle(int nIndex)
{
    auto & curr = controlMapPoint(nIndex);
    const auto & prePos = controlMapPoint(nIndex - 1).pos;
    const auto & nextPos = controlMapPoint(nIndex + 1).pos;

    // 将 prePos 与 nextPos 点平移到过 curr.pos 点，斜率同 prePos -> nextPos 的直线上
    QPointF offset = curr.pos - Internal::projection(curr.pos, prePos, nextPos);
    QPointF preMovePos = prePos + offset;
    QPointF nextMovePos = nextPos + offset;

    // 保证 preMovePos 在 curr.pos 的左边，nextMovePos 在 curr.pos 的右边
    if(preMovePos.x() > curr.pos.x()){
        preMovePos = 2 *curr.pos - preMovePos;
    }
    if(nextMovePos.x() < curr.pos.x()){
        nextMovePos = 2 *curr.pos - nextMovePos;
    }

    curr.handleL = curr.pos + (preMovePos - curr.pos) * 0.25;
    curr.handleR = curr.pos + (nextMovePos - curr.pos) * 0.25;
}



ITEM_POINT_S &CurveModel::controlMapPoint(int nIndex)
{
    auto & controls = *m_pControls;
    auto & points = *m_pPoints;
    return points[controls[nIndex]];
}

