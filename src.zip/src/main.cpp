#include <QApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QStandardItemModel>
#include <QDateTime>

#include "CurveModel.h"

int main(int argc, char *argv[])
{
#if defined(Q_OS_WIN)
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif

    QApplication app(argc, argv);

    CurveModel model;
    model.setCurveData({1,2,3,4,5,6});
    model.setControl({0,2,5});

    QQmlApplicationEngine engine;
    engine.rootContext()->setContextProperty("lineModel", &model);
    engine.load(QUrl(QStringLiteral("qrc:/modelMapper.qml")));
    // engine.load(QUrl(QStringLiteral("qrc:/main.qml")));
    if (engine.rootObjects().isEmpty())
        return -1;

    return app.exec();
}