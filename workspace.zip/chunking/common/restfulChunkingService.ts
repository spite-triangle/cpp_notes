/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

import { createServiceIdentifier } from '../../../util/common/services';
import { CancellationToken } from '../../../util/vs/base/common/cancellation';
import { Uri } from '../../../vscodeTypes';
import { FileChunk } from './chunk';

export interface RestfulChunkingOptions {
	/**
	 * The desired maximum length of each chunk in tokens
	 */
	readonly maxTokenLength?: number;
	readonly validateChunkLengths?: boolean;
	readonly includeExtraBodyOutsideRange?: boolean; // only gets applied if limitToRange is set
}

export interface IRestfulChunkingService {
	/**
	 * Splits `text` into smaller chunks of roughly equal length using a scrolling window approach.
	 * This method makes a RESTful request to a chunking service endpoint.
	 */
	chunkFile(
		endpointUrl: string,
		fileUri: Uri,
		text: string,
		options: RestfulChunkingOptions,
		token: CancellationToken
	): Promise<FileChunk[]>;
}

export const IRestfulChunkingService = createServiceIdentifier<IRestfulChunkingService>('IRestfulChunkingService');
