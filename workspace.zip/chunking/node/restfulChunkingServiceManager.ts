/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

import * as express from 'express';
import * as http from 'http';
import { CancellationToken } from '../../../util/vs/base/common/cancellation';
import { Uri } from '../../../vscodeTypes';
import { FileChunk } from '../common/chunk';
import { IRestfulChunkingService } from '../common/restfulChunkingService';

export class RestfulChunkingServiceManager implements IRestfulChunkingServiceManager {
	private server: http.Server | null = null;
	private readonly app: express.Application;
	private readonly chunkingService: IRestfulChunkingService;

	constructor(chunkingService: IRestfulChunkingService) {
		this.chunkingService = chunkingService;
		this.app = express();
		this.setupRoutes();
	}

	private setupRoutes(): void {
		// POST /chunk - Chunk text content
		this.app.post('/chunk', express.json(), async (req, res) => {
			try {
				const { text, maxTokenLength, validateChunkLengths, includeExtraBodyOutsideRange } = req.body;

				// For this example, we'll use a dummy URI
				const dummyUri = Uri.parse('file:///dummy.txt');

				// Call the chunking service
				const chunks: FileChunk[] = await this.chunkingService.chunkFile(
					'http://localhost:3000/chunk', // dummy endpoint URL
					dummyUri,
					text,
					{
						maxTokenLength,
						validateChunkLengths,
						includeExtraBodyOutsideRange
					},
					CancellationToken.None
				);

				res.json({ chunks });
			} catch (error) {
				console.error('Error in chunking endpoint:', error);
				res.status(500).json({ error: 'Failed to chunk content' });
			}
		});
	}

	public async start(port: number): Promise<void> {
		// 启动RESTful服务
		if (!this.server) {
			this.server = this.app.listen(port, () => {
				console.log(`RESTful chunking service listening on port ${port}`);
			});
		}
	}

	public async stop(): Promise<void> {
		// 停止RESTful服务
		if (this.server) {
			this.server.close();
			this.server = null;
		}
	}
}
