/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

import { CancellationToken } from '../../../util/vs/base/common/cancellation';
import { IInstantiationService } from '../../../util/vs/platform/instantiation/common/instantiation';
import { Uri } from '../../../vscodeTypes';
import { ILogService } from '../../log/common/logService';
import { IFetcherService, Response } from '../../networking/common/fetcherService';
import { ITelemetryService } from '../../telemetry/common/telemetry';
import { FileChunk } from '../common/chunk';
import { IRestfulChunkingService } from './restfulChunkingService';

export class RestfulChunkingService implements IRestfulChunkingService {
	declare _serviceBrand: undefined;

	constructor(
		@IFetcherService private readonly fetcherService: IFetcherService,
		@ITelemetryService private readonly telemetryService: ITelemetryService,
		@ILogService private readonly logService: ILogService,
		@IInstantiationService private readonly instantiationService: IInstantiationService
	) { }

	async chunkFile(
		endpointUrl: string,
		fileUri: Uri,
		text: string,
		options: {
			maxTokenLength?: number;
			validateChunkLengths?: boolean;
			includeExtraBodyOutsideRange?: boolean;
		},
		token: CancellationToken
	): Promise<FileChunk[]> {
		try {
			// Prepare the request body
			const requestBody = {
				text: text,
				maxTokenLength: options.maxTokenLength,
				validateChunkLengths: options.validateChunkLengths,
				includeExtraBodyOutsideRange: options.includeExtraBodyOutsideRange
			};

			// Make the HTTP POST request to the RESTful endpoint
			const response: Response = await this.fetcherService.fetch(endpointUrl, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
				},
				json: requestBody,
				timeout: 30000, // 30 second timeout
			});

			if (!response.ok) {
				throw new Error(`HTTP ${response.status}: ${response.statusText}`);
			}

			// Parse the response
			const result = await response.json();

			// Convert the response to FileChunk[] format
			if (!Array.isArray(result.chunks)) {
				throw new Error('Invalid response format: chunks array expected');
			}

			return result.chunks.map((chunk: any) => ({
				file: fileUri,
				text: chunk.text,
				rawText: chunk.rawText,
				isFullFile: chunk.isFullFile,
				range: {
					startLineNumber: chunk.range.start,
					startColumn: 0,
					endLineNumber: chunk.range.end,
					endColumn: 0
				}
			}));

		} catch (error) {
			this.logService.error(`Failed to chunk file ${fileUri} via RESTful service:`, error);
			throw error;
		}
	}
}
