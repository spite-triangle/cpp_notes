/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

import * as express from 'express';
import { CancellationToken } from '../../../util/vs/base/common/cancellation';
import { Uri } from '../../../vscodeTypes';
import { FileChunk } from '../common/chunk';
import { IRestfulChunkingService } from '../common/restfulChunkingService';

// This is a simple example of how a RESTful chunking service endpoint might be implemented
// In a real implementation, this would be part of a separate service or microservice

export class RestfulChunkingEndpoint {
	private readonly app: express.Application;
	private readonly chunkingService: IRestfulChunkingService;

	constructor(chunkingService: IRestfulChunkingService) {
		this.chunkingService = chunkingService;
		this.app = express();
		this.setupRoutes();
	}

	private setupRoutes(): void {
		// POST /chunk - Chunk text content
		this.app.post('/chunk', express.json(), async (req, res) => {
			try {
				const { text, maxTokenLength, validateChunkLengths, includeExtraBodyOutsideRange } = req.body;

				// For this example, we'll use a dummy URI
				const dummyUri = Uri.parse('file:///dummy.txt');

				// Call the chunking service
				const chunks: FileChunk[] = await this.chunkingService.chunkFile(
					'http://localhost:3000/chunk', // dummy endpoint URL
					dummyUri,
					text,
					{
						maxTokenLength,
						validateChunkLengths,
						includeExtraBodyOutsideRange
					},
					CancellationToken.None
				);

				res.json({ chunks });
			} catch (error) {
				console.error('Error in chunking endpoint:', error);
				res.status(500).json({ error: 'Failed to chunk content' });
			}
		});
	}

	public listen(port: number): void {
		this.app.listen(port, () => {
			console.log(`RESTful chunking service listening on port ${port}`);
		});
	}
}
