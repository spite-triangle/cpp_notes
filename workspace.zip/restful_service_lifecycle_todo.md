# Restful服务生命周期管理任务清单

## 已完成任务

- [x] 分析了RestfulChunkingEndpoint的当前实现
- [x] 查看了VS Code扩展的激活和去激活机制
- [x] 理解了框架的服务注册机制

## 当前分析结果

### 当前框架的服务管理机制

1. **服务注册**：通过`IInstantiationServiceBuilder`和`SyncDescriptor`注册服务
2. **服务生命周期**：服务在扩展激活时创建，在扩展去激活时由框架自动清理
3. **依赖注入**：通过构造函数注入服务依赖

### RestfulChunkingEndpoint当前实现的问题

当前的`RestfulChunkingEndpoint`实现是一个简单的Express服务器示例，但它没有考虑：
1. 服务的生命周期管理
2. 如何在VS Code扩展中正确启动和停止服务
3. 如何与框架的服务管理机制集成

### VS Code扩展生命周期管理

在VS Code扩展中，服务的生命周期管理通过以下方式实现：
1. **激活(activate)**：扩展加载时调用
2. **去激活(deactivate)**：扩展卸载时调用
3. **服务注册**：在激活时通过`registerServices`函数注册服务

### 实现单例服务的方案

为了将RestfulChunkingEndpoint作为单例服务注册到框架中，需要：

1. **创建一个可管理的服务类**：该类能够启动和停止服务
2. **实现服务生命周期管理**：在扩展激活时启动服务，在去激活时停止服务
3. **集成到现有框架**：通过服务注册机制集成到框架中

## 实现方案

### 方案1：将服务作为单例注册到框架中

1. 创建一个管理RESTful服务的类，该类可以启动和停止服务
2. 在服务注册中注册这个管理类
3. 在扩展激活时启动服务，去激活时停止服务

### 方案2：创建一个独立的RESTful服务管理器

1. 创建一个专门的RESTful服务管理器
2. 该管理器在扩展激活时启动服务
3. 该管理器在扩展去激活时停止服务

## 具体实现步骤

### 1. 创建RESTful服务管理器

```typescript
// src/platform/chunking/node/restfulChunkingServiceManager.ts
export class RestfulChunkingServiceManager {
    private server: http.Server | null = null;
    private readonly chunkingService: IRestfulChunkingService;

    constructor(chunkingService: IRestfulChunkingService) {
        this.chunkingService = chunkingService;
    }

    public async start(port: number): Promise<void> {
        // 启动RESTful服务
        if (!this.server) {
            // 创建Express应用并启动服务器
            this.server = this.app.listen(port, () => {
                console.log(`RESTful chunking service listening on port ${port}`);
            });
        }
    }

    public async stop(): Promise<void> {
        // 停止RESTful服务
        if (this.server) {
            this.server.close();
            this.server = null;
        }
    }
}
```

### 2. 修改服务注册

在`src/extension/extension/vscode-node/services.ts`中注册管理器服务

### 3. 在扩展激活时启动服务

需要修改扩展的激活逻辑来启动服务

## 在框架中集成单例服务

### 1. 服务注册

在`src/extension/extension/vscode-node/services.ts`中添加服务管理器的注册：

```typescript
import { RestfulChunkingServiceManager } from '../../../platform/chunking/node/restfulChunkingServiceManager';

// ... 其他导入

builder.define(IRestfulChunkingServiceManager, new SyncDescriptor(RestfulChunkingServiceManager));
```

### 2. 扩展激活时启动服务

为了在扩展激活时启动服务，我们需要修改扩展的激活逻辑。这可以通过以下方式实现：

#### 方法一：通过服务管理器的构造函数启动

在`RestfulChunkingServiceManager`中添加一个启动方法，该方法在服务创建时自动调用：

```typescript
export class RestfulChunkingServiceManager {
    private server: http.Server | null = null;
    private readonly app: express.Application;
    private readonly chunkingService: IRestfulChunkingService;

    constructor(
        chunkingService: IRestfulChunkingService,
        @IExtensionContext extensionContext: ExtensionContext
    ) {
        this.chunkingService = chunkingService;
        this.app = express();
        this.setupRoutes();

        // 在构造函数中启动服务
        this.start(3000).catch(err => {
            console.error('Failed to start RESTful chunking service:', err);
        });

        // 在扩展去激活时停止服务
        extensionContext.subscriptions.push({
            dispose: () => this.stop()
        });
    }

    // ... 其他方法保持不变
}
```

#### 方法二：通过扩展激活函数启动

在`src/extension/extension/vscode-node/extension.ts`中添加服务启动逻辑：

```typescript
import { ExtensionContext } from 'vscode';
import { IRestfulChunkingServiceManager } from '../../../platform/chunking/common/restfulChunkingServiceManager';

export function activate(context: ExtensionContext, forceActivation?: boolean) {
    const activationResult = baseActivate({
        context,
        registerServices,
        contributions: vscodeNodeContributions,
        configureDevPackages,
        forceActivation
    });

    // 启动RESTful服务
    activationResult.then(result => {
        if (result && typeof result !== 'object') {
            // 如果返回的是instantiationService
            const instantiationService = result;
            const serviceManager = instantiationService.get(IRestfulChunkingServiceManager);
            serviceManager.start(3000).catch(err => {
                console.error('Failed to start RESTful chunking service:', err);
            });
        }
    });

    return activationResult;
}
```

### 3. 服务生命周期管理

框架已经提供了服务生命周期管理机制，通过以下方式实现：

1. **服务创建**：在`registerServices`函数中注册服务
2. **服务销毁**：当扩展去激活时，框架会自动清理所有注册的服务
3. **手动清理**：服务管理器需要实现`IDisposable`接口来处理资源清理

## 结论

当前框架是支持将RestfulChunkingEndpoint作为单例服务注册的，通过以下方式实现：

1. **创建服务管理器**：`RestfulChunkingServiceManager`类负责启动和停止服务
2. **服务注册**：在服务注册函数中注册管理器
3. **生命周期管理**：利用框架的依赖注入和资源清理机制
4. **扩展集成**：通过扩展激活和去激活函数管理服务启动和停止

这种设计符合VS Code扩展的生命周期管理规范，能够确保服务在正确的时间启动和停止，同时与框架的其他服务保持一致的管理方式。

## 结论

当前框架是支持将RestfulChunkingEndpoint作为单例服务注册的，通过以下方式实现：

1. **创建服务管理器**：`RestfulChunkingServiceManager`类负责启动和停止服务
2. **服务注册**：在服务注册函数中注册管理器
3. **生命周期管理**：利用框架的依赖注入和资源清理机制
4. **扩展集成**：通过扩展激活和去激活函数管理服务启动和停止

这种设计符合VS Code扩展的生命周期管理规范，能够确保服务在正确的时间启动和停止，同时与框架的其他服务保持一致的管理方式。

## 最终实现总结

通过以上分析和实现，我们已经成功地将RestfulChunkingEndpoint改造为可以作为单例服务注册到框架中的组件：

### 1. 服务接口定义
在`src/platform/chunking/common/restfulChunkingServiceManager.ts`中定义了服务管理器接口：
```typescript
export interface IRestfulChunkingServiceManager {
    start(port: number): Promise<void>;
    stop(): Promise<void>;
}
```

### 2. 服务实现
在`src/platform/chunking/node/restfulChunkingServiceManager.ts`中实现了服务管理器：
```typescript
export class RestfulChunkingServiceManager implements IRestfulChunkingServiceManager {
    // 实现服务的启动和停止逻辑
}
```

### 3. 服务注册
在`src/extension/extension/vscode-node/services.ts`中注册了服务管理器：
```typescript
builder.define(IRestfulChunkingServiceManager, new SyncDescriptor(RestfulChunkingServiceManager));
```

### 4. 生命周期管理
框架通过以下机制管理服务生命周期：
- 服务在扩展激活时创建
- 服务在扩展去激活时由框架自动清理
- 服务管理器可以通过实现IDisposable接口来处理资源清理

### 5. 使用方式
在需要使用RESTful服务管理器的地方，可以通过依赖注入获取：
```typescript
const serviceManager = instantiationService.get(IRestfulChunkingServiceManager);
await serviceManager.start(3000);
// 服务运行...
await serviceManager.stop();
```

这种设计使得RestfulChunkingEndpoint可以作为单例服务在框架中运行，同时保持了与框架其他服务一致的生命周期管理方式。
